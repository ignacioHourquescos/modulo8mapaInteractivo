var mapa

function inicializaMapa () {
  mapa = new google.maps.Map(document.getElementById('map'), {
    center: {
      lat: -34.6037389,
      lng: -58.3815704
    },
    zoom: 3
  })

    // Completar para agregar una variable de tipo latlng con el constructor

    // Crear un marcador con la variable creada

    // Cambiar el tipo de mapa para que se vea con imágenes satelitales
}
